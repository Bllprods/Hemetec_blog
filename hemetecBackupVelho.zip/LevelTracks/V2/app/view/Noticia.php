<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="css/Cabecario.css">
    <link rel="stylesheet" href="css/Noticia.css">
    <link rel="stylesheet" href="css/Fontes.css">
    <link rel="stylesheet" href="css/Cores.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<title>Noticia</title>
</head>
<body>
	  <?php include 'Layout/Header.php'; ?><br><br>
<div id="Noticias">

        </div>
       	<div id="NoticiaCorpo">
       		<div id="Imagem1"></div>
     	<div id="Text1">
     	 Lorem ipsum dolor sit amet. Qui vero dolorum est fugit 
			 quae eum incidunt voluptate est galisum dolorem? Qui 
			 nihil consequatur qui perspiciatis porro et velit illum. 
			 Qui culpa perferendis et architecto amet non nisi 
			 praesentium ut eveniet molestiae cum soluta sequi qui 
			 omnis ipsam est enim dolorem? Ut voluptatem 
			 voluptatem et explicabo facilis qui consequatur 
			 explicabo.
			  Lorem ipsum dolor sit amet. Qui vero dolorum est fugit 
			 quae eum incidunt voluptate est galisum dolorem? Qui 
			 nihil consequatur qui perspiciatis porro et velit illum. 
			 Qui culpa perferendis et architecto.
    	</div><br><br>
  			<div id="Imagem2"></div>
		<div id="Text2">
			 Lorem ipsum dolor sit amet. Qui vero dolorum est fugit 
			 quae eum incidunt voluptate est galisum dolorem? Qui 
			 nihil consequatur qui perspiciatis porro et velit illum. 
			 Qui culpa perferendis et architecto amet non nisi 
			 praesentium ut eveniet molestiae cum soluta sequi qui 
			 omnis ipsam est enim dolorem? Ut voluptatem 
			 voluptatem et explicabo facilis qui consequatur 
			 explicabo.
			  Lorem ipsum dolor sit amet. Qui vero dolorum est fugit 
			 quae eum incidunt voluptate est galisum dolorem? Qui 
			 nihil consequatur qui perspiciatis porro et velit illum. 
			 Qui culpa perferendis et architecto.
	</div>
</div>
	<div id="RodapeNoticia">

	</div>
</body>
</html>