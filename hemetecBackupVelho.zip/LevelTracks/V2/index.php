<?php
    header("Location: public/router.php");
?>