<div id="Conteudo">
    <div id="formulario">
        <h2>Excluir Postagem</h2>
                    <form method="post" action="router.php?action=excluir">
                        <input type="text" name="idNot">
                        <button type="submit" class="btn-excluir">Excluir</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>
</html>