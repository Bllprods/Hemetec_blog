<div id="Conteudo">

<form method="post" action="router.php?action=consultaP" enctype="multipart/form-data">

    <input placeholder="Digite o nome da notícia" type="text" id="pesquisa" name="pesquisa">
    <button type="submit" class="publicar">Pesquise</button>
    <table id="BuscaTodos" style="">
    <thead>
        <tr>
        <th>Título</th>
        <th>Conteudo</th>
        <th>Email</th>
        <th>CPF</th>
        <th>Livro</th>
        <th>Dia Alugado</th>
        <th>Devolutiva</th>
        </tr>
        </thead>
</form>
</div>